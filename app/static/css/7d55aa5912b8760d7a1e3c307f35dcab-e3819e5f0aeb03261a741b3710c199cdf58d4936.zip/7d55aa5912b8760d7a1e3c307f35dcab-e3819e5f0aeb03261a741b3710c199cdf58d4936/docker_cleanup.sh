#!/usr/bin/env bash

removevolumes()  {
    sudo docker volume rm $(sudo docker volume ls -qf dangling=true)
    sudo docker volume ls -qf dangling=true | xargs -r sudo docker volume rm
}

removenetwork() {
    sudo docker network ls
    sudo docker network ls | grep "bridge"
    sudo docker network rm $(sudo docker network ls | grep "bridge" | awk '/ / { print $1 }')
}

removecontainers() {
    sudo docker stop $(sudo docker ps -aq)
    sudo docker rm $(sudo docker ps -aq)
}

armaggedon() {
    removevolumes
    removenetwork
    removecontainers
}

armaggedon